﻿using System.Reflection;

[assembly: AssemblyTitle("NUnrar.Mono")]
[assembly: AssemblyProduct("NUnrar.Mono")]
