﻿using System.Reflection;

[assembly: AssemblyTitle("NUnrar.3.5")]
[assembly: AssemblyProduct("NUnrar.3.5")]
