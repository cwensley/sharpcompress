﻿using System.Reflection;

[assembly: AssemblyTitle("NUnrar.Portable")]
[assembly: AssemblyProduct("NUnrar.Portable")]
