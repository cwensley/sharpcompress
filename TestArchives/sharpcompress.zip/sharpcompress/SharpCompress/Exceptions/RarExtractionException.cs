﻿
namespace SharpCompress
{
    public class RarExtractionException : RarException
    {
        public RarExtractionException(string message)
            : base(message)
        {
        }
    }
}
