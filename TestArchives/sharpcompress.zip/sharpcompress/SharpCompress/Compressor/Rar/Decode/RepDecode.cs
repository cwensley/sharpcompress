
namespace SharpCompress.Compressor.Rar.decode
{
    internal class RepDecode : Decode
    {
        internal RepDecode()
            : base(new int[Compress.RC])
        {
        }
    }
}