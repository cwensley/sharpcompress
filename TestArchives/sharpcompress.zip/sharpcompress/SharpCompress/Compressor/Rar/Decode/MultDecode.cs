namespace SharpCompress.Compressor.Rar.decode
{
    internal class MultDecode : Decode
    {
        internal MultDecode()
            : base(new int[Compress.MC20])
        {
        }
    }
}