﻿using System.Reflection;

[assembly: AssemblyTitle("NUnrar.Silverlight")]
[assembly: AssemblyProduct("NUnrar.Silverlight")]
