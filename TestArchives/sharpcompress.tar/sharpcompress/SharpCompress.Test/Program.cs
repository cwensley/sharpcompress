﻿
namespace SharpCompress.Test
{
    static class Program
    {
        static void Main()
        {
        }
    }
}
