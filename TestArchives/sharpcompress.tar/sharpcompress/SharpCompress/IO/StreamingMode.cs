﻿
namespace SharpCompress.IO
{
    internal enum StreamingMode
    {
        Streaming,
        Seekable,
    }
}
